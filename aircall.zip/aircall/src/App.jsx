import React from 'react';
import ReactDOM from 'react-dom';
import Activity from './components/Activity.jsx';
import Footer from './Footer.jsx';

import Header from './Header.jsx';
import {
  BrowserRouter as Router,
  Routes,
  Route
  
} from "react-router-dom";
import Archives from './components/Archives.jsx';
import SingleCall from './components/SingleCall.jsx';

const App = () => {
  return (
    <section className="main">
    <div className="container">
        <div className="full">
            <div className="outer-sec">
                <div className="grey-top">
                    <ul>
                        <li><span className="color-dots"></span></li>
                        <li><span className="color-dots"></span></li>
                        <li><span className="color-dots"></span></li>
                    </ul>
                    <h5>(12) Aircall Phone</h5>
                </div>

                <div className="phone-body">
                        <div className="tab-section">

                        <Router>
      
                        <Header/>
        <Routes>
          <Route exact path="/archives" element={<Archives/>}/>
          <Route exact path="/" element={<Activity/>}/>
          <Route exact path="/singlecall/:id" element={<SingleCall/>}/>

       
        
        </Routes>
    </Router>

                        

                         

                          </div>
                          </div>

                          <Footer/>

                </div>
                </div>
                </div>

                </section>
  );
};

ReactDOM.render(<App/>, document.getElementById('app'));

export default App;
