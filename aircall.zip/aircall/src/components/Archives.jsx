import { faArchive, faPhoneSlash, faPhoneVolume } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React,{useEffect,useState} from 'react'
import axios from 'axios'
import moment from "moment";
import ReactTooltip from 'react-tooltip';
import { ToastProvider, useToasts } from 'react-toast-notifications';
import { useNavigate } from "react-router-dom";


const ActivityBlock = () => {
    const [state, setstate] = useState([]);
    const [archived,setArchived]=useState(false);
    const { addToast } = useToasts()

    const navigate =useNavigate();

  const moveToSingleCallPage=(id)=>{
    navigate(`/singlecall/${id}`)

  }


    const archiveCall=(id)=>{

        axios.post(`https://aircall-job.herokuapp.com/activities/${id}`,{is_archived:false}).then(data=>{
            setArchived(!archived);
            addToast("Call UnArchived", {
                appearance: 'success',
                autoDismiss: true,
              })
        })

    }


    useEffect(() => {
        axios.get("https://aircall-job.herokuapp.com/activities").then(data=>{
            setstate(data["data"]);
        })
        
    }, [archived])
    return (
        <div id="tab-1" className="tab-content current" style={{overflowY:"scroll",height:"430px",cursor:"pointer"}}>
        <div className="archive-call">
            <span><FontAwesomeIcon icon={faArchive}/></span> 
            <h6>Archive all calls</h6>
        </div>
       {
           state.filter(ele=>ele.is_archived).map(ele=>(<React.Fragment  key={ele.id}>
           
           <div  className="call-date">
            <h5><span>{moment(ele.created_at).format("MMM Do YYYY") }</span></h5>
        </div>
        <div className="call-log">
            <span className="icon"><ReactTooltip /><FontAwesomeIcon data-tip="Un Archive Call" onClick={()=>archiveCall(ele.id)} icon={faPhoneVolume}/></span> 
            <div className="caller-details">
                <h6>{ele.from} </h6>
                <p>tried to call on {ele.to}</p>
            </div>
            <div className="call-time">
            <ReactTooltip /> <p  data-tip="Call Details"  onClick={()=>moveToSingleCallPage(ele.id)} className="time">{moment(ele.created_at).format("LT") }</p>
            </div>
        </div>
           </React.Fragment>))
       }
       
      
     
       
    </div>
    )
}


const Archives = () => (
    <ToastProvider>
      <ActivityBlock />
    </ToastProvider>
  );
export default Archives
