import React,{useState,useEffect} from 'react'
import moment from "moment";
import { faArchive, faPhoneSlash, faPhoneVolume } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useParams } from "react-router-dom";
import axios from "axios";


const SingleCall = () => {
    const [state, setstate] = useState({})
    const {id}=useParams();


    useEffect(() => {

        axios.get(`https://aircall-job.herokuapp.com/activities/${id}`).then(data=>{
            setstate(data["data"]);
        })
       
    }, [])





    return (
        <React.Fragment key={state.id}>
           
        <div  className="call-date">
         <h5><span>{moment(state.created_at).format("MMM Do YYYY") }</span></h5>
     </div>
     <div className="call-log">
         <div className="caller-details">
             <h6>{state.from} </h6>
             <p>tried to call on {state.to}</p>
         </div>
         <div className="call-time">
             <p className="time">{moment(state.created_at).format("LT") }</p>
         </div>
     </div>
        </React.Fragment>
    )
}

export default SingleCall
