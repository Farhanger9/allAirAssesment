import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPhoneAlt } from '@fortawesome/free-solid-svg-icons';
import {
  Link
  
} from "react-router-dom";

const Header = () => {
  return (
    <ul className="tabs">
    <li className="tab-link current" data-tab="tab-1"><span><FontAwesomeIcon icon={faPhoneAlt}/></span> Activity</li>
    <li  className="tab-link" > <Link style={{color:"black",textDecoration:"none"}}  to="/">All Calls</Link></li>

    <li  className="tab-link" > <Link style={{color:"black",textDecoration:"none"}}  to="/archives">Archive Calls</Link></li>
    <li className="tab-link" data-tab="tab-4"><i className="fas fa-cogs"></i></li>
</ul>
  );
};

export default Header;
