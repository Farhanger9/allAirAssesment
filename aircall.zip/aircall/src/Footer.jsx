import { faCog, faPhoneAlt, faUser } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'


const Footer = () => {
    return (
        <div className="footer">
        <ul>
            <li className="active"><FontAwesomeIcon icon={faPhoneAlt}/></li>
            <li><FontAwesomeIcon icon={faUser}/></li>
            <li><img src="https://gos32.s3.us-east-2.amazonaws.com/dialpad.png" /></li>
            <li><FontAwesomeIcon icon={faCog}/></li>
            <li>
                <p style={{border: "1px solid #cfcfcf",padding: "5px 2px","margin": 0, borderRadius: "50%",width: "20px",height: "20px","margin": "0 auto"}}>
                    <span className="circle-green"></span>
                </p>
            </li>
        </ul>
    </div>
    )
}

export default Footer
